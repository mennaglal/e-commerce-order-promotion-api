<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payment_attempts', function (Blueprint $table) {
            $table->id();

            $table->foreignId('order_id')
                ->constrained()
                ->restrictOnDelete();

            $table->string('gateway');
            $table->string('payment_method');

            $table->uuid('idempotency_key')->unique();

            $table->decimal('amount', 12, 2);
            $table->string('currency', 3);

            $table->string('status', 30)->default('pending');

            $table->string('payment_id', 150)->nullable();
            $table->string('invoice_id', 150)->nullable();
            $table->string('transaction_id', 150)->nullable();

            $table->text('invoice_url')->nullable();

            $table->string('failure_code', 100)->nullable();
            $table->text('failure_message')->nullable();

            $table->json('gateway_response')->nullable();

            $table->timestamp('attempted_at')->nullable();
            $table->timestamp('paid_at')->nullable();

            $table->timestamps();

            $table->unique(
                ['gateway', 'payment_id'],
                'payment_attempt_gateway_payment_unique'
            );

            $table->unique(
                ['gateway', 'transaction_id'],
                'payment_attempt_gateway_transaction_unique'
            );

            $table->index(['order_id', 'status']);


        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_attempts');
    }
};
