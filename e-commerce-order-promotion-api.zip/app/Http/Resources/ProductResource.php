<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'sku' => $this->sku,
            'description' => $this->description,
            'price' => $this->price,

            'stock_quantity' => $this->stock_quantity,

            'is_available' => $this->status
                && $this->stock_quantity > 0,

            'status' => $this->status
                ? 'active'
                : 'inactive',

            'created_at' => $this->created_at?->toISOString(),
        ];
    }
}
