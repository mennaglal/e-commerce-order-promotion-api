<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PaymentAttempt extends Model
{
    use HasFactory;

    public const STATUS_PENDING = 'pending';
    public const STATUS_PROCESSING = 'processing';
    public const STATUS_SUCCEEDED = 'succeeded';
    public const STATUS_FAILED = 'failed';
    public const STATUS_UNKNOWN = 'unknown';
    public const STATUS_CANCELLED = 'cancelled';

    public const STATUSES = [
        self::STATUS_PENDING,
        self::STATUS_PROCESSING,
        self::STATUS_SUCCEEDED,
        self::STATUS_FAILED,
        self::STATUS_UNKNOWN,
        self::STATUS_CANCELLED,
    ];

    public const STATUS_TRANSITIONS = [
        self::STATUS_PENDING => [
            self::STATUS_PROCESSING,
            self::STATUS_CANCELLED,
        ],

        self::STATUS_PROCESSING => [
            self::STATUS_SUCCEEDED,
            self::STATUS_FAILED,
            self::STATUS_UNKNOWN,
            self::STATUS_CANCELLED,
        ],

        self::STATUS_UNKNOWN => [
            self::STATUS_SUCCEEDED,
            self::STATUS_FAILED,
        ],

        self::STATUS_SUCCEEDED => [],
        self::STATUS_FAILED => [],
        self::STATUS_CANCELLED => [],
    ];

    protected $fillable = [
        'order_id',
        'gateway',
        'payment_method',
        'amount',
        'currency',
        'payment_id',
        'invoice_id',
        'transaction_id',
        'invoice_url',
        'failure_code',
        'failure_message',
        'attempted_at',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'gateway_response' => 'array',
        'attempted_at' => 'datetime',
        'paid_at' => 'datetime',
    ];

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function canTransitionTo(string $status): bool
    {
        return in_array(
            $status,
            self::STATUS_TRANSITIONS[$this->status] ?? [],
            true
        );
    }
}
