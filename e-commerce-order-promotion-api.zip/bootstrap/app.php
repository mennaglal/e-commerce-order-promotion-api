<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use App\Http\Responses\ApiResponse;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->redirectGuestsTo('/admin/login');
    })
    ->withExceptions(function (Exceptions $exceptions) {

        $exceptions->render(function (
            ThrottleRequestsException $e,
            Request $request
        ) {
            if ($request->is('api/*')) {

                $response = ApiResponse::error(
                    'Too many requests. Please try again later.',
                    429
                );

                // Preserve Retry-After and other throttle headers.
                foreach ($e->getHeaders() as $key => $value) {
                    $response->headers->set($key, $value);
                }

                return $response;
            }
        });

    })->create();
